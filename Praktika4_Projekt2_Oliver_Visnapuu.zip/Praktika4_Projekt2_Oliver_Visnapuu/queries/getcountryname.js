const db = require('../config/index');
//var pgp = require("pg-promise")();
//var db = pgp(config.getDbConnectionString());

//const pool = require('../config/db');

module.exports = function (app) {
    app.get("/api/country/name/:namecountry", async (req, res) => {
        res.set('Access-Control-Allow-Origin', '*')
        db.any("SELECT c.*, ci.id as city_id, ci.name as city_name, ci.district as district, ci.population as city_population FROM country c INNER JOIN city ci ON c.code = ci.countrycode WHERE c.name = '" + req.params.namecountry + "'")
            .then(function (data) {
                res.json({
                    status: "success",
                    data,
                })
            })
            .catch((err) => {
                res.json({
                    description: "SQL not working",
                    error: err,
                });
            });
    })
};