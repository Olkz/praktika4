const db = require('../config/index');
//var pgp = require("pg-promise")();
//var db = pgp(config.getDbConnectionString());

//const pool = require('../config/db');

module.exports = function (app) {
    app.get("/api/countries/:continent", async (req, res) => {
        res.set('Access-Control-Allow-Origin', '*')
        db.any("SELECT DISTINCT c.continent AS Continent, c.name AS Country, ci.name AS Capital FROM country c INNER JOIN city ci ON c.capital = ci.id WHERE continent = '" + req.params.continent + "'")
            .then(function (data) {
                res.json({
                    status: "success",
                    data,
                })
            })
            .catch((err) => {
                res.json({
                    description: "SQL not working",
                    error: err,
                });
            });
    })
};