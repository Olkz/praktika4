const db = require('../config/index');
//var pgp = require("pg-promise")();
//var db = pgp(config.getDbConnectionString());

//const pool = require('../config/db');

module.exports = function (app) {
    app.get("/api/controllerssensors", async (req, res) => {
        res.set('Access-Control-Allow-Origin', '*')
        db.any("SELECT DISTINCT cs.id_controller, c.controllername, cs.id_sensor, s.sensorname FROM controller c INNER JOIN controller_sensor cs ON c.id = cs.id_controller INNER JOIN sensor s ON cs.id_sensor = s.id")
            .then(function (data) {
                res.json({
                    status: "success",
                    data,
                })
            })
            .catch((err) => {
                res.json({
                    description: "Can’t find any room",
                    error: err,
                });
            });
    })
};