var express = require("express");
var app = express();
var PORT = process.env.PORT || 8000;
var cors = require("cors");

var getrooms = require('./controllers/getrooms');
var getroomsensors = require('./controllers/roomsensors');
var getcontrollers = require('./controllers/getcontrollers');
var getcontrollerssensors = require('./controllers/getcontrollerssensors');
var getroomdatamaxdate = require('./controllers/getroomdatatoday');

app.use(cors());

//Ülesanne 1 ****************************************************************

//Ülesanne 1.1, 1.2, 1.3 ****************************************************************

// localhost:8000
app.get("/", function(req, res){
    res.send("Hello, World");
});

// localhost:8000/tere
app.get("/tere", function(req, res){
    res.send("Tere, Maailm");
});

app.get("/api/roomss", function(req, res){
    res.send("toad");
});

//curl -i http://dev.vk.edu.ee/~natalia/hitsaproject/api/controllers
//[{"id":1,"controllername":"Raspberry pi","description":null},{"id":2,"controllername":"Arduino","description":null},{"id":3,"controllername":"Arduino Uno","description":"Mac adress: 00:AA:BB:CC:DE:02"},{"id":4,"controllername":"Arduino uno output devices","description":"my mac"}]

//Ül 1. Ruumid ****************************************************************

getrooms(app);
//{"status":"success","data":[{"room":"208"},{"room":"28"},{"room":"44"},{"room":"12a"},{"room":"112"}]}

getroomsensors(app);
//{"status":"success","data":[{"sensorname":"Grove VOC and eCO2 Gas Sensor"},{"sensorname":"High Accuracy Temperature"},{"sensorname":"PIR Motion Sensor"},{"sensorname":"Loudness Sensor"},{"sensorname":"Sunlight Sensor"},{"sensorname":"Light Sensor"},{"sensorname":"Ventilator"},{"sensorname":"Led lamp 3"},{"sensorname":"Led lamp 2"},{"sensorname":"Led lamp 1"},{"sensorname":"Temperature and Humidity Sensor Pro"}]}

//Ül 2.1 Kontrollerid andmebaasis ****************************************************************

getcontrollers(app);
//{"status":"success","data":[{"controllername":"Arduino Uno"},{"controllername":"Arduino"},{"controllername":"Raspberry pi"},{"controllername":"Arduino uno output devices"}]}

//Ül 2.2 Näidata, millised andurid on konkreetse kontrolleriga ühendatud ****************************************************************
getcontrollerssensors(app);
//{"status":"success","data":[{"id_controller":2,"controllername":"Arduino","id_sensor":2,"sensorname":"Temperature sensor"},{"id_controller":3,"controllername":"Arduino Uno","id_sensor":11,"sensorname":"Sunlight Sensor"},{"id_controller":4,"controllername":"Arduino uno output devices","id_sensor":16,"sensorname":"Ventilator"},{"id_controller":2,"controllername":"Arduino","id_sensor":4,"sensorname":"Photorezistor"},{"id_controller":4,"controllername":"Arduino uno output devices","id_sensor":13,"sensorname":"Led lamp 1"},{"id_controller":1,"controllername":"Raspberry pi","id_sensor":5,"sensorname":"RuuviTag"},{"id_controller":3,"controllername":"Arduino Uno","id_sensor":12,"sensorname":"Light Sensor"},{"id_controller":4,"controllername":"Arduino uno output devices","id_sensor":15,"sensorname":"Led lamp 3"},{"id_controller":3,"controllername":"Arduino Uno","id_sensor":7,"sensorname":"Temperature and Humidity Sensor Pro"},{"id_controller":3,"controllername":"Arduino Uno","id_sensor":6,"sensorname":"Grove VOC and eCO2 Gas Sensor"},{"id_controller":3,"controllername":"Arduino Uno","id_sensor":10,"sensorname":"Loudness Sensor"},{"id_controller":3,"controllername":"Arduino Uno","id_sensor":8,"sensorname":"High Accuracy Temperature"},{"id_controller":3,"controllername":"Arduino Uno","id_sensor":9,"sensorname":"PIR Motion Sensor"},{"id_controller":1,"controllername":"Raspberry pi","id_sensor":1,"sensorname":"ruuvi"},{"id_controller":4,"controllername":"Arduino uno output devices","id_sensor":14,"sensorname":"Led lamp 2"},{"id_controller":2,"controllername":"Arduino","id_sensor":3,"sensorname":"DHT22 temperature-humidity sensor"}]}

//Ül 2.3 Näidata auditooriumi nr 44 andurite andmeid täna ****************************************************************
getroomdatamaxdate(app);
//Tehtud max kuupäevaga sest TODAY'ga polnud ühtegi väärtust
//{"status":"success","data":[{"date_time":"2022-05-12T00:02:54.653Z","sensor_value":260,"unit":"lm","max_data_date":"2022-05-12T01:28:12.242Z"},{"date_time":"2022-05-12T00:02:54.653Z","sensor_value":23.8,"unit":"C","max_data_date":"2022-05-12T01:28:12.242Z...

app.listen(PORT);
