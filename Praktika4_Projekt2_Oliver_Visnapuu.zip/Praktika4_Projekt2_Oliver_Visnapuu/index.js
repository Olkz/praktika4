var express = require("express");
var app = express();
var PORT = process.env.PORT || 8000;
var cors = require("cors");

var getcountries = require('./queries/getcountries');
var getcountriescontinent = require('./queries/getcountriescontinent');
var getcityid = require('./queries/getcityid');
var getcityname = require('./queries/getcityname');
var getcountryid = require('./queries/getcountryid');
var getcountryname = require('./queries/getcountryname');

//Looge 2. projekt, kasutades  kolledži serveril world_student andmebaasi PostgreSQL,  ja looge andmete lugemiseks API päringud: 

//a. näidata kõiki riike 
getcountries(app);
//"status":"success","data":[{"name":"Bangladesh"},{"name":"Venezuela"},{"name":"Mayotte"},{"name":"Luxembourg"},{"name":"Czech Republic"},{"name":"Sweden"},{"name":"Dominican Republic"},{"name":"Saint Helena"},{"name":"Cambodia"},{"name":"Ireland"}...

//b. näidata kõiki määratud mandri riike (riigi nimi, pealinn) 
getcountriescontinent(app);
//{"status":"success","data":[{"continent":"Africa","country":"Algeria","capital":"Alger"},{"continent":"Africa","count...

//c. näidata täielikku teavet määratud linna kohta (2 GET - päringut: linnakoodi ja nime järgi) 
getcityid(app);
//{"status":"success","data":[{"id":7,"name":"Haag","countrycode":"NLD","district":"Zuid-Holland","population":440900}]}

getcityname(app);
//{"status":"success","data":[{"id":7,"name":"Haag","countrycode":"NLD","district":"Zuid-Holland","population":440900}]}

//d. näidata täielikku teavet määratud riigi kohta (teave riigi ja linnade kohta). Andmete lugemiseks looge ka 2 päringut: riigi koodi ja nime järgi. 
getcountryid(app);
//{"status":"success","data":[{"code":"EST","name":"Estonia","continent":"Europe","region":"Baltic Countries","surfacearea":45227,"indepyear":1991,"population":1340602,"lifeexpectancy":69.5,"gnp":5328,"gnpold":3371,"localname":"Eesti","governmentform":"Republic","headofstate":"Toomas Hendrik Ilves","capital":4084,"code2":"EE","city_id":3792,"city_name":"Tartu",..-

getcountryname(app);
//{"status":"success","data":[{"code":"EST","name":"Estonia","continent":"Europe","region":"Baltic Countries","surfacearea":45227,"indepyear":1991,"population":1340602,"lifeexpectancy":69.5,"gnp":5328,"gnpold":3371,"localname":"Eesti","governmentform":"Republic","headofstate":"Toomas Hendrik Ilves","capital":4084,"code2":"EE","city_id":3792,"city_name":"Tartu",...

app.use(cors());
app.listen(PORT);
