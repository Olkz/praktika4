const db = require('../config/index');
//var pgp = require("pg-promise")();
//var db = pgp(config.getDbConnectionString());

//const pool = require('../config/db');

module.exports = function (app) {
    app.get("/api/city/name/:namecity", async (req, res) => {
        res.set('Access-Control-Allow-Origin', '*')
        db.any("SELECT * FROM city WHERE name = '" + req.params.namecity + "'")
            .then(function (data) {
                res.json({
                    status: "success",
                    data,
                })
            })
            .catch((err) => {
                res.json({
                    description: "SQL not working",
                    error: err,
                });
            });
    })
};